import edu.princeton.cs.algs4.WeightedQuickUnionUF;
public class Percolation {
	private WeightedQuickUnionUF net, connectionToVirtualTop;
	private final boolean[] siteStatus; // 0 mean blocked site, 1 mean open site
	private final int gridSize, virtualBottomSiteId;
	public Percolation(int n){
		if(n <= 0){
			throw new IllegalArgumentException("n must be positive");
		}
		virtualBottomSiteId = n*n+1;
		gridSize = n;
		net = new WeightedQuickUnionUF(n*n+2);
		connectionToVirtualTop = new WeightedQuickUnionUF(n*n+1);
		siteStatus = new boolean[n*n+1];
	}
	 private void validate(int row, int col) throws IndexOutOfBoundsException{
		 if(row < 1 || row > gridSize || col < 1 || col > gridSize){
			 throw new IndexOutOfBoundsException("Invalid input for coordinate of site in the grid");
		 }
	 }
	private int mapToId(int row, int col){
		validate(row, col);
		return (row-1)*gridSize + col;
	}
	public void open(int row, int col){
		validate(row, col);
		int id = mapToId(row, col);
		if(siteStatus[id]) { // the site has already been opened
			return;
		} else {
			siteStatus[id] = true;
			if( col > 1 && siteStatus[mapToId(row, col-1)]){ // check if the site on the left exists and is open
				net.union(id, mapToId(row, col-1));
				connectionToVirtualTop.union(id, mapToId(row, col-1));
			} 
			if (row > 1 && siteStatus[mapToId(row-1, col)]){
				connectionToVirtualTop.union(id, mapToId(row-1, col));
				net.union(id, mapToId(row-1, col));
			} else {  // this case row == 1
			}
			if (col < gridSize && siteStatus[mapToId(row, col+1)]){
				net.union(id, mapToId(row, col+1));
				connectionToVirtualTop.union(id, mapToId(row, col + 1));
			} 
			if (row < gridSize && siteStatus[mapToId(row+1, col)]){
				connectionToVirtualTop.union(id, mapToId(row + 1, col) );
				net.union(id, mapToId(row+1, col));
			}
			if(row == 1){
				net.union(id, 0);
				connectionToVirtualTop.union(id, 0);
			}
			if(row == gridSize) {
				net.union(id, virtualBottomSiteId);
			}
		}
	}
	public boolean isOpen(int row, int col){
		validate(row, col);
		return siteStatus[mapToId(row, col)];
	}
	
	public boolean isFull(int row, int col){
		validate(row, col);
		return connectionToVirtualTop.connected(mapToId(row, col), 0);
	}
	public boolean percolates(){
		return net.connected(0, virtualBottomSiteId);
	}
}
